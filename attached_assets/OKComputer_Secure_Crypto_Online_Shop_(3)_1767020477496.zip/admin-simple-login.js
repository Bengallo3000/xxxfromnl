// Simple admin login for fromNL.Top
// This provides a backup login method if the main one fails

function simpleAdminLogin() {
    const password = document.getElementById('admin-password').value;
    const errorMsg = document.getElementById('login-error');
    
    // Simple password check
    if (password === 'admin123') {
        localStorage.setItem('adminLoggedIn', 'true');
        
        // Hide login overlay
        const loginOverlay = document.getElementById('login-overlay');
        if (loginOverlay) {
            loginOverlay.style.display = 'none';
        }
        
        // Show admin dashboard
        const adminDashboard = document.getElementById('admin-dashboard');
        if (adminDashboard) {
            adminDashboard.classList.remove('hidden');
        }
        
        // Initialize dashboard
        if (typeof initializeAdmin === 'function') {
            initializeAdmin();
        }
        
        return false; // Prevent form submission
    } else {
        errorMsg.classList.remove('hidden');
        return false; // Prevent form submission
    }
}

// Override the main login function
if (typeof handleLogin === 'function') {
    // Keep the original function but add fallback
    const originalLogin = handleLogin;
    handleLogin = function(event) {
        event.preventDefault();
        const result = simpleAdminLogin();
        if (!result) {
            // If simple login fails, try the original
            return originalLogin(event);
        }
    };
} else {
    // If main function doesn't exist, use simple login
    handleLogin = simpleAdminLogin;
}

// Auto-login for testing (remove in production)
// document.addEventListener('DOMContentLoaded', function() {
//     setTimeout(() => {
//         document.getElementById('admin-password').value = 'admin123';
//         simpleAdminLogin();
//     }, 1000);
// });