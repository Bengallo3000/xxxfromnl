# fromNL.Top - Premium Narcotics E-Commerce Design

## Design Philosophy

### Core Visual Language
- **Premium Dutch Aesthetic**: Clean, sophisticated design inspired by Dutch design principles
- **Professional Trust**: Establish credibility through refined typography and balanced layouts
- **Product Focus**: Emphasize product quality through high-resolution imagery and detailed presentations
- **Accessibility**: Ensure all users can navigate and purchase safely and securely

### Color Palette (Configurable)
- **Primary Base**: Deep forest green (#1a472a) - representing natural, organic quality
- **Secondary Base**: Warm amber (#d4af37) - symbolizing premium quality and Dutch heritage
- **Accent Base**: Clean white (#ffffff) and soft gray (#f8f9fa)
- **Warning/Alert**: Muted orange (#ff6b35) for important notifications

### Typography (Configurable)
- **Display Font**: "Canela" - Bold serif for impactful headings and branding
- **Body Font**: "Suisse Int'l" - Clean, neutral sans-serif for readability
- **Accent Font**: "JetBrains Mono" - Monospace for technical elements and codes

### Visual Effects & Styling

#### Used Libraries
- **Anime.js**: Smooth micro-interactions and cart animations
- **ECharts.js**: Advanced analytics and sales visualization in admin
- **Pixi.js**: Dynamic background effects and product showcases
- **Typed.js**: Dynamic text effects for hero sections
- **Splide**: Premium product image carousels and galleries
- **Splitting.js**: Advanced text animations for headings

#### Animation Effects
- **Product Reveal**: Staggered fade-in animations for product grids
- **Cart Interactions**: Smooth slide-in cart with bounce effects
- **Image Transitions**: Ken Burns effect for hero images
- **Loading States**: Skeleton screens with shimmer effects
- **Hover States**: 3D tilt and depth shadow effects
- **Scroll Animations**: Parallax effects for background elements

#### Header Effects
- **Dynamic Background**: Animated gradient flow with subtle movement
- **Product Showcase**: Rotating hero images with smooth transitions
- **Trust Indicators**: Animated badges and security icons
- **Search Expansion**: Morphing search bar with focus animations

#### Interactive Elements
- **Product Cards**: Hover reveals with quick-add and wishlist
- **Image Galleries**: Zoom and pan with touch/swipe support
- **Filter Animations**: Smooth category transitions
- **Cart Updates**: Real-time quantity adjustments with visual feedback
- **Checkout Flow**: Multi-step progress with validation animations

#### Theme System
- **Light Theme**: Clean, bright interface with high contrast
- **Dark Theme**: Sophisticated dark mode with accent highlights
- **Auto Theme**: System preference detection
- **Custom Colors**: Admin-configurable color schemes
- **Typography Controls**: Font family and size adjustments
- **Layout Options**: Grid/list view toggles

#### Background Styling
- **Consistent Base**: Subtle texture overlays for depth
- **Section Differentiation**: Gradient borders and spacing
- **Decorative Elements**: Geometric patterns at page edges
- **Focus Areas**: Elevated cards with soft shadows
- **Loading States**: Progressive image loading with blur-up

#### Mobile Responsiveness
- **Touch-First Design**: Large tap targets and gesture support
- **Swipe Navigation**: Product galleries and category filters
- **Optimized Cart**: Full-screen overlay for mobile checkout
- **Thumb-Friendly**: Navigation and controls within reach
- **Performance**: Lazy loading and optimized images

#### Security & Trust Visual Cues
- **SSL Indicators**: Green lock icons and secure badges
- **Privacy Badges**: GDPR compliance and data protection
- **Payment Security**: Crypto wallet verification displays
- **Age Verification**: Modal overlay with verification steps
- **Trust Signals**: Customer reviews and ratings displays

#### Product Presentation
- **High-Resolution Galleries**: Multiple angles and zoom functionality
- **Strain Information**: Detailed terpene and cannabinoid profiles
- **Lab Results**: Certificate of analysis display
- **Dosage Guides**: Visual dosage recommendations
- **Related Products**: Intelligent cross-selling suggestions

#### Admin Interface Styling
- **Dashboard Cards**: Clean metrics with progress indicators
- **Data Visualization**: Consistent color schemes for charts
- **Form Design**: Intuitive input fields with validation
- **Theme Configurator**: Real-time preview of changes
- **Bot Controls**: Telegram integration with message previews
- **Upload Interface**: Drag-and-drop with progress indicators